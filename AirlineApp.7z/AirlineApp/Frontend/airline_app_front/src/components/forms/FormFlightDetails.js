import React, { Fragment, useEffect, useState } from "react";
import DatePicker from "react-date-picker";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";
import FormInfoPassenger from "./FormInfoPassenger";

export default function FormFlightDetails() {
  const [oneWayOrRound, setOneWayOrRound] = useState();
  const [isOneWayOrRoundChosen, setIsOneWayOrRoundChosen] = useState();
  const [startDate, setStartDate] = useState(new Date());
  const [value, onChange] = useState(new Date());
  const [isDatePick, setIsDatePick] = useState(true);

  useEffect(() => {
    setIsDatePick(true);
  }, [value]);

  const [dropdownChooseOneWay, setDropdownChooseOneWay] = useState(false);
  const openCloseDropdownChooseOneWay = () => {
    setDropdownChooseOneWay(!dropdownChooseOneWay);
  };

  
  const handleFirstNameChange = (e) => {
  };
  const handleLastNameChange = (e) => {
  };
  const handleNationality = (e) => {
  };
  const handleIdentification = (e) => {
  };
  const handleAge = (e) => {
  };

  return (
    <Fragment>
      <Dropdown
        isOpen={dropdownChooseOneWay}
        toggle={openCloseDropdownChooseOneWay}
        style={{ textAlign: "right", margin: "20px 5px" }}
      >
        <DropdownToggle caret>Choose one way or round</DropdownToggle>
        <DropdownMenu>
          <DropdownItem
            onClick={() => {
              setOneWayOrRound("one");
              setIsOneWayOrRoundChosen(true);
            }}
          >
            One way
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setOneWayOrRound("two");
              setIsOneWayOrRoundChosen(true);
            }}
          >
            Round
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
      {isOneWayOrRoundChosen && (
        <DatePicker onChange={onChange} value={value}></DatePicker>
      )}
      {isDatePick && (
        <FormInfoPassenger
          handleFirstNameChange={handleFirstNameChange}
          handleLastNameChange={handleLastNameChange}
          handleNationality={handleNationality}
          handleIdentification={handleIdentification}
          handleAge={handleAge}
        ></FormInfoPassenger>
      )}
    </Fragment>
  );
}
