import React, { Fragment, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";

export default function FormInfoPassenger(props) {
  const {
    handleFirstNameChange,
    handleLastNameChange,
    handleNationality,
    handleIdentification,
    handleAge,
  } = props;

  const [dropdownBaggage, setDropdownBaggage] = useState(false);
  const openCloseDropdownBaggage = () => {
    setDropdownBaggage(!dropdownBaggage);
  };

  const [baggage, setBaggage] = useState(false);
  const [baggageChosen, setIsBaggageChosen] = useState(false);

  return (
    <div style={{ margin: "20px" }}>
      <h2 style={{ margin: "1px" }}>New post</h2>
      <input
        placeholder="First name"
        type={"text"}
        name="firstName"
        onChange={handleFirstNameChange()}
        autoComplete="false"
      ></input>
      <br></br>
      <input
        placeholder="Last name"
        type={"text"}
        name="lastName"
        onChange={handleLastNameChange()}
        autoComplete="false"
      ></input>
      <br></br>
      <input
        placeholder="Nationality"
        type={"text"}
        name="nationality"
        onChange={handleNationality()}
        autoComplete="false"
      ></input>
      <br></br>
      <input
        placeholder="Identification"
        type={"text"}
        name="identification"
        onChange={handleIdentification()}
        autoComplete="false"
      ></input>
      <br></br>
      <input
        placeholder="Age"
        type={"number"}
        name="age"
        onChange={handleAge()}
        autoComplete="false"
      ></input>
      <br></br>
      <Dropdown
        isOpen={dropdownBaggage}
        toggle={openCloseDropdownBaggage}
        style={{ textAlign: "right", margin: "20px 5px" }}
      >
        <DropdownToggle caret>Choose one way or round</DropdownToggle>
        <DropdownMenu>
          <DropdownItem
            onClick={() => {
              setBaggage(false);
              setIsBaggageChosen(true);
            }}
          >
            No baggage
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setBaggage(true);
              setIsBaggageChosen(true);
            }}
          >
            Baggage
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
    </div>
  );
}
