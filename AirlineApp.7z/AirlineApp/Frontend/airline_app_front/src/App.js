import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Link, Routes} from "react-router-dom";
import Home from './pages/Home';
import Success from './pages/Success';
import Fail from './pages/Fail';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to='/'>Home</Link>
            </li>
            <li>
              <Link to='/sucess'>Success</Link>
            </li>
            <li>
              <Link to='/fail'>Fail</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path='/' element={<Home></Home>}>
          </Route>
          <Route path='/success' element={<Success></Success>}>
          </Route>
          <Route path='/fail' element={<Fail></Fail>}>
          </Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
