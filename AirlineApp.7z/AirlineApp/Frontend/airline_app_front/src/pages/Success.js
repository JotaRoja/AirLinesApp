import React, { Fragment, useEffect, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";

export default function Success() {

  return (
    <Fragment>
        <div>Prueba S</div>
    </Fragment>
  );
}
