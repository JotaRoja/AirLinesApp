import React, { Fragment, useEffect, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";

export default function Fail() {

  return (
    <Fragment>
    <div>Prueba F</div>
    </Fragment>
  );
}
