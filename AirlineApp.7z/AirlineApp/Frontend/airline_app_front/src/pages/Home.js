import React, { Fragment, useEffect, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
} from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import FormFlightDetails from "../components/forms/FormFlightDetails";

export default function Home() {
  //   const [datos, setDatos] = useState({
  //     postsTitle: "",
  //     postsBody: "",
  //   });
  const [threads, setThreads] = useState([{ title: "thread5" }]);
  const [chosenThread, setChosenThread] = useState({});

  //Dropdowns
  const [dropdownOrigin, setDropdownOrigin] = useState(false);
  const openCloseDropdownOrigin = () => {
    setDropdownOrigin(!dropdownOrigin);
  };
  const [dropdownDestinations, setDropdownDestinations] = useState(false);
  const openCloseDropdownDestinations = () => {
    setDropdownDestinations(!dropdownDestinations);
  };

  //   useEffect(() => {
  //     fetch("https://localhost:7260/CreateThreads")
  //       .then((response) => response.json())
  //       .then((data) => {
  //         setThreads(data.value);
  //         console.log(`Data: ${data}`);
  //       });
  //   }, []);

  //   const handleCategoryChange = (category) => {
  //     setCategory(category);
  //     console.log(category);
  //   };

  return (
    <Fragment>
      <Dropdown
        isOpen={dropdownOrigin}
        toggle={openCloseDropdownOrigin}
        style={{ textAlign: "right", margin: "20px 5px" }}
      >
        <DropdownToggle caret>Thread</DropdownToggle>
        <DropdownMenu>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread1");
            }}
          >
            Thread A
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread2");
            }}
          >
            Thread B
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread3");
            }}
          >
            Thread C
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread4");
            }}
          >
            Thread D
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
      <Dropdown
        isOpen={dropdownDestinations}
        toggle={openCloseDropdownDestinations}
        style={{ textAlign: "right", margin: "20px 5px" }}
      >
        <DropdownToggle caret>Thread</DropdownToggle>
        <DropdownMenu>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread1");
            }}
          >
            Thread A
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread2");
            }}
          >
            Thread B
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread3");
            }}
          >
            Thread C
          </DropdownItem>
          <DropdownItem
            onClick={() => {
              setChosenThread("thread4");
            }}
          >
            Thread D
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
      {true && <FormFlightDetails></FormFlightDetails>}
      {/* <PostForm
        datos={datos}
        setDatos={setDatos}
        isForm={isForm}
        setIsForm={setIsForm}
        handleTitleChange={handleTitleChange}
        handleBodyChange={handleBodyChange}
        errors={errors}
        setErrors={setErrors}
        isError={isError}
        setIsError={setIsError}
      ></PostForm> */}
    </Fragment>
  );
}
