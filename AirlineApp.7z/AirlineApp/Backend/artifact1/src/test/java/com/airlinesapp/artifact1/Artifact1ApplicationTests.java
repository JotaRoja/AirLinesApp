package com.airlinesapp.artifact1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Artifact1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
