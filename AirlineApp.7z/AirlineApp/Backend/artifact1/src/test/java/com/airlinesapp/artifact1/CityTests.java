package com.airlinesapp.artifact1;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Passenger;
import com.airlinesapp.artifact1.repository.CityRepository;
import com.airlinesapp.artifact1.repository.PassengerRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class CityTests {
    @Autowired
    private CityRepository cRep;
    @Autowired
    private TestEntityManager eManager;

    @Test
    public void addCity(){
        City city1 = new City();
        City city2 = new City();

        city1.setName("Sevilla");
        city2.setName("Santiago");

        eManager.persist(city1);
        eManager.persist(city2);
    }
}
