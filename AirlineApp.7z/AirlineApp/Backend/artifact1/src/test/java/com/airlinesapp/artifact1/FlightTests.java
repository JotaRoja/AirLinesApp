package com.airlinesapp.artifact1;

import com.airlinesapp.artifact1.model.Passenger;
import com.airlinesapp.artifact1.repository.PassengerRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class FlightTests {
    @Autowired
    private PassengerRepository pRep;
    @Autowired
    private TestEntityManager eManager;

    @Test
    public void addPassenger(){
        Passenger passenger1 = new Passenger();
        Passenger passenger2 = new Passenger();
        Passenger passenger3 = new Passenger();
        passenger1.setFirstName("Jose");
        passenger2.setFirstName("Pepe");
        passenger3.setFirstName("Manué");
        passenger1.setLastName("Jarra");
        passenger2.setLastName("Vaso");
        passenger3.setLastName("Copa");
        passenger1.setAge(14);
        passenger2.setAge(23);
        passenger3.setAge(43);
        passenger1.setNif("42afdf");
        passenger2.setNif("34fdsf");
        passenger3.setNif("asdf324");
        eManager.persist(passenger1);
        eManager.persist(passenger2);
        eManager.persist(passenger3);
    }
}
