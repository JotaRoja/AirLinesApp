package com.airlinesapp.artifact1.controller;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/city")
public class CityController {

    @Autowired
    private CityService cityService;

    @PostMapping("/addCity")
    public String add(@RequestBody City city){
        cityService.saveCity(city);
        return "New city added :)";
    }

    @GetMapping("/getAll")
    public List<City> getCities(){
        return cityService.getCities();
    }

}
