package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Passenger;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

public interface PassengerService {
    public Passenger savePassenger(Passenger Passenger);
    public List<Passenger> getPassengers();
}
