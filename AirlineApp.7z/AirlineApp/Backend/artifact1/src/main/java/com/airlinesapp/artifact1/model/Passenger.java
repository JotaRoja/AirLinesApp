package com.airlinesapp.artifact1.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

import static org.springframework.util.Assert.notNull;

@Entity
public class Passenger implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String firstName;

    private String lastName;
    private String passport;
    private int age;
    @OneToMany(mappedBy = "passenger", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Ticket> passengerTickets;

//    public Passenger(String firstName, String lastName, String passport, int age){
//        notNull(firstName, "Method called with null parameter (firstName)");
//        notNull(lastName, "Method called with null parameter (lastName)");
//        notNull(passport, "Method called with null parameter (passport)");
//        notNull(age, "Method called with null parameter (age)");
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.passport = passport;
//        this.age = age;
//    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public List<Ticket> getPassengerTickets() {
        return passengerTickets;
    }

    public void setPassengerTickets(List<Ticket> passengerTickets) {
        this.passengerTickets = passengerTickets;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNif() {
        return passport;
    }

    public void setNif(String nif) {
        this.passport = nif;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
