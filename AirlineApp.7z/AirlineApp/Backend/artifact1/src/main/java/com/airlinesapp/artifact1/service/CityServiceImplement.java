package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.repository.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityServiceImplement implements CityService {

    @Autowired
    private CityRepository cityRepository;
    @Override
    public City saveCity(City city) {
        return cityRepository.save(city);
    }
    @Override
    public List<City> getCities() {
        return cityRepository.findAll();
    }
}
