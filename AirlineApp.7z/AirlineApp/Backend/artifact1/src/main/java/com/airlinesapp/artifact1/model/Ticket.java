package com.airlinesapp.artifact1.model;

import javax.persistence.*;

import static org.springframework.util.Assert.notNull;

@Entity
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name="passenger_id", nullable=false)
    private Passenger passenger;

    @ManyToOne
    @JoinColumn(name="flight_id", nullable = false)
    private Flight flight;
    private int price;

//    private boolean baggage;

//    public Ticket(Passenger passenger, Flight flight, int price, boolean baggage){
//        notNull(passenger, "Method called with null parameter (passenger)");
//        notNull(flight, "Method called with null parameter (flight)");
//        notNull(price, "Method called with null parameter (price)");
//        notNull(baggage, "Method called with null parameter (baggage)");
//        this.passenger = passenger;
//        this.flight = flight;
//        this.price = price;
//        this.baggage = baggage;
//    }
}
