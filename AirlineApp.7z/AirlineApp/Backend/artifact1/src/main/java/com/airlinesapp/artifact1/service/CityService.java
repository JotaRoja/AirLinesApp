package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

public interface CityService {
    public City saveCity(City city);
    public List<City> getCities();
}
