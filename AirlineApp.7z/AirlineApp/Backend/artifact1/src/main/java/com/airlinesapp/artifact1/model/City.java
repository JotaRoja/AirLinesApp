package com.airlinesapp.artifact1.model;

import org.springframework.boot.context.properties.ConstructorBinding;

import javax.persistence.*;

import java.util.List;

import static org.springframework.util.Assert.notNull;

@Entity
@ConstructorBinding
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;

//    public City(String name){
//        notNull(name, "Method called with null parameter (name)");
//        this.name = name;
//    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

}
