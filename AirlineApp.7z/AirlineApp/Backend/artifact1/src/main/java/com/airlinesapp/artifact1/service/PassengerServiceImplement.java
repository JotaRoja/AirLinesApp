package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Passenger;
import com.airlinesapp.artifact1.repository.CityRepository;
import com.airlinesapp.artifact1.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassengerServiceImplement  implements PassengerService{

    @Autowired
    private PassengerRepository passengerRepository;
    @Override
    public Passenger savePassenger(Passenger passenger) {
        return passengerRepository.save(passenger);
    }
    @Override
    public List<Passenger> getPassengers() {
        return passengerRepository.findAll();
    }
}
