package com.airlinesapp.artifact1.controller;

import com.airlinesapp.artifact1.model.Flight;
import com.airlinesapp.artifact1.model.Passenger;
import com.airlinesapp.artifact1.service.FlightService;
import com.airlinesapp.artifact1.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/passenger")
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @PostMapping("/addPassenger")
    public String add(@RequestBody Passenger passenger){
        passengerService.savePassenger(passenger);
        return "New passanger added :O";
    }

    @GetMapping("/getAll")
    public List<Passenger> getFlights(){
        return passengerService.getPassengers();
    }
}
