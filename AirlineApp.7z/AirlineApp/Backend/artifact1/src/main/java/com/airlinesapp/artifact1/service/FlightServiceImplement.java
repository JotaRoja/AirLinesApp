package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Flight;
import com.airlinesapp.artifact1.repository.CityRepository;
import com.airlinesapp.artifact1.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightServiceImplement implements FlightService{

    @Autowired
    private FlightRepository flightRepository;
    @Override
    public Flight saveFlight(Flight flight) {
        return flightRepository.save(flight);
    }
    @Override
    public List<Flight> getFlights() {
        return flightRepository.findAll();
    }
}
