package com.airlinesapp.artifact1.controller;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Flight;
import com.airlinesapp.artifact1.service.CityService;
import com.airlinesapp.artifact1.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flight")
public class FlightController {

    @Autowired
    private FlightService flightService;

    @PostMapping("/addFlight")
    public String add(@RequestBody Flight flight){
        flightService.saveFlight(flight);
        return "New flight added :)";
    }

    @GetMapping("/getAll")
    public List<Flight> getFlights(){
        return flightService.getFlights();
    }
}
