package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Flight;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

public interface FlightService {
    public Flight saveFlight(Flight flight);
    public List<Flight> getFlights();
}
