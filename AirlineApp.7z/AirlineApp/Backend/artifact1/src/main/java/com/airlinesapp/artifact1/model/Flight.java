package com.airlinesapp.artifact1.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static org.springframework.util.Assert.notNull;

@Entity
public class Flight {
    @Id
    @GeneratedValue
    private int id;
    private String originCity;
    private String destinyCity;
    private String departureDate;
    private String arrivalDate;
    private float price;

    @OneToMany(mappedBy = "flight", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Ticket> tickets;

    private boolean isFull;

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

//    public Flight(City originCity, City destinyCity, String departureDate, String arrivalDate, float price){
//        notNull(originCity, "Method called with null parameter (originCity)");
//        notNull(destinyCity, "Method called with null parameter (destinyCity)");
//        notNull(departureDate, "Method called with null parameter (departureDate)");
//        notNull(arrivalDate, "Method called with null parameter (arrivalDate)");
//        this.originCity = originCity;
//        this.destinyCity = destinyCity;
//        this.departureDate = departureDate;
//        this.arrivalDate = arrivalDate;
//    }


    public boolean isFull() {
        return isFull;
    }
    public void setFull(boolean full) {
        isFull = full;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getOriginCity() {
        return originCity;
    }
    public void setOriginCity(String originCity) {
        this.originCity = originCity;
    }

    public String getDestinyCity() {
        return destinyCity;
    }
    public void setDestinyCity(String destinyCity) {
        this.destinyCity = destinyCity;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
