package com.airlinesapp.artifact1.service;

import com.airlinesapp.artifact1.model.City;
import com.airlinesapp.artifact1.model.Ticket;
import com.airlinesapp.artifact1.repository.CityRepository;
import com.airlinesapp.artifact1.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketServiceImplement  implements Ticketservice{

    @Autowired
    private TicketRepository ticketRepository;
    @Override
    public Ticket saveTicket(Ticket ticket) {
        return ticketRepository.save(ticket);
    }
    @Override
    public List<Ticket> getTickets() {
        return ticketRepository.findAll();
    }
}
